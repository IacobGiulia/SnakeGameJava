import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class App extends JFrame {

    public App() {
        setTitle("Snake Game");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JLabel label = new JLabel("Snake Game", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 40));
        add(label, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());

        JButton button = new JButton("Play");
        JButton button2 = new JButton("Exit");
        JButton button3 = new JButton("Rules");

        button.setFont(new Font("Arial", Font.BOLD, 20));
        button2.setFont(new Font("Arial", Font.BOLD, 20));
        button3.setFont(new Font("Arial", Font.BOLD, 20));
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                JFrame gameFrame = new JFrame("Snake Game");
                gameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                gameFrame.setSize(500, 500);
                gameFrame.setLocationRelativeTo(null);

                Game game = new Game(500, 500);
                gameFrame.add(game);
                gameFrame.pack();
                gameFrame.setVisible(true);
                game.requestFocus();
            }
        });
        button2.addActionListener(e -> System.exit(0));
        button3.addActionListener(e -> Rules());
        buttonPanel.add(button);
        buttonPanel.add(button2);
        buttonPanel.add(button3);
        add(buttonPanel, BorderLayout.SOUTH);
        setVisible(true);
    }
    private void Rules(){
        JDialog dialog = new JDialog(this, "Game's Rules", true);
        dialog.setSize(500, 500);
        dialog.setLocationRelativeTo(null);
        dialog.setLayout(new BorderLayout());

        JTextArea rulesText = new JTextArea();

        rulesText.setText("""
                
                
                1. Use the WASD keys to control the snake.
                
                2. Collect the coins in order to grow.
                
                3. Don't hit the walls or yourself!
                
                4. Try to collect as many coins as you can.
                """);
        rulesText.setFont(new Font("Arial", Font.PLAIN, 20));
        rulesText.setEditable(false);
        rulesText.setWrapStyleWord(true);
        rulesText.setLineWrap(true);

        JScrollPane scrollPane = new JScrollPane(rulesText);
        dialog.add(scrollPane, BorderLayout.CENTER);

        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dialog.dispose());
        dialog.add(closeButton, BorderLayout.SOUTH);

        dialog.setVisible(true);
    }

    public static void main(String[] args) {
        new App();
    }
}
