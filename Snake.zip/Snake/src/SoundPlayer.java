import javax.sound.sampled.*;
import java.io.IOException;
import java.net.URL;

public class SoundPlayer{
    public static void playSound(String filePath){
        try{
            URL soundURL =SoundPlayer.class.getResource(filePath);
            if(soundURL == null){
                System.out.println("Sound file not found");
                return;
            }

        AudioInputStream audioStream = AudioSystem.getAudioInputStream(soundURL);
        Clip clip = AudioSystem.getClip();
        clip.open(audioStream);
        clip.start();
        } catch(UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            e.printStackTrace();

}
    }
        }