import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Random;

public class Game extends JPanel implements ActionListener, KeyListener {
    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode() == KeyEvent.VK_W && speedY != 1) {
            speedX = 0;
            speedY = -1;
        }
        else if(e.getKeyCode() == KeyEvent.VK_S && speedY != -1) {
            speedX = 0;
            speedY = 1;
        }
        else if(e.getKeyCode() == KeyEvent.VK_A && speedX != 1) {
            speedX = -1;
            speedY = 0;
        }
        else if(e.getKeyCode() == KeyEvent.VK_D && speedX != -1) {
            speedX = 1;
            speedY = 0;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        move();
        repaint();

        if(gameOver == true){
            loop.stop();
        }
    }

    private class Square{
        int x;
        int y;

        Square(int X, int Y){
            x=X;
            y=Y;
        }
    }
    int boardWidth, boardHeight;
    int SquareSize = 25;

    Square snakeHead;
    ArrayList<Square> snakeBody;
    Square money;
    Random random;
    Timer loop;
    int speedX;
    int speedY;
    boolean gameOver = false;

    Image background;
    Image moneyImage;

    Game(int boardWidth, int boardHeight){
        this.boardWidth = boardWidth;
        this.boardHeight = boardHeight;
        setPreferredSize(new Dimension(boardWidth, boardHeight));
        setBackground(Color.WHITE);

        background = new ImageIcon(getClass().getResource("/pics/Background.png")).getImage();

        if(background == null)
            System.out.println("Imaginea nu a fost corect incarcata");
        snakeHead = new Square(5, 5);
        snakeBody = new ArrayList<Square>();
        money = new Square(10, 10);
        random = new Random();
        loop = new Timer(100, this);
        speedX = 0;
        speedY = 0;
        addKeyListener(this);
        setFocusable(true);
        loop.start();
    }

    public void paintComponent(Graphics g){
        super.paintComponent(g);

        g.drawImage(background, 0, 0, boardWidth, boardHeight, this);
        draw(g);


    }

    public void placeFood()
    {
        money.x = random.nextInt(boardWidth/SquareSize);
        money.y = random.nextInt(boardHeight/SquareSize);
    }

    public void draw(Graphics g){
        g.setColor(new Color(0,100,0));
        g.fillRect(snakeHead.x * SquareSize, snakeHead.y * SquareSize, SquareSize, SquareSize);

        g.setColor(Color.YELLOW);
        g.fillOval(money.x * SquareSize, money.y * SquareSize, SquareSize, SquareSize);

        for(int i=0;i<snakeBody.size();i++){
            Square snakePart = snakeBody.get(i);
            g.setColor(new Color(0,100, 0));
            g.fillRect(snakePart.x * SquareSize, snakePart.y * SquareSize, SquareSize, SquareSize);
        }

        g.setFont(new Font("Times New Roman", Font.BOLD, 18));
        if(gameOver == true){
            g.setColor(Color.RED);
            g.drawString("Game over: " + String.valueOf(snakeBody.size()), SquareSize - 16, SquareSize);

        }
        else{
            g.setColor(Color.BLACK);
            g.drawString("Score: "+ String.valueOf(snakeBody.size()), SquareSize - 16, SquareSize);
        }
    }

    public boolean collision(Square square1, Square square2)
    {
        return square1.x == square2.x && square1.y == square2.y;
    }
    public void move()
    {
        if(collision(money, snakeHead) == true)
        {
            snakeBody.add(new Square(money.x, money.y));
            placeFood();
            SoundPlayer.playSound("/Sounds/Money.wav");
        }

        for(int i = snakeBody.size() - 1; i >= 0; i--)
        {
            Square snakePart = snakeBody.get(i);
            if(i==0)
            {
                snakePart.x = snakeHead.x;
                snakePart.y = snakeHead.y;
            }
            else{
                Square prevSnakePart = snakeBody.get(i-1);
                snakePart.x = prevSnakePart.x;
                snakePart.y = prevSnakePart.y;
            }
        }

        snakeHead.x += speedX;
        snakeHead.y += speedY;

        for(int i = 0; i<snakeBody.size(); i++)
        {
            Square snakePart = snakeBody.get(i);
            if(collision(snakePart, snakeHead) == true)
            {
                gameOver = true;
                SoundPlayer.playSound("/Sounds/GameOver.wav");
            }
        }

        if(snakeHead.x * SquareSize < 0 || snakeHead.x * SquareSize > boardWidth ||
           snakeHead.y * SquareSize < 0 || snakeHead.y * SquareSize > boardHeight)
        {
            gameOver = true;
            SoundPlayer.playSound("/Sounds/GameOver.wav");
        }
    }

}